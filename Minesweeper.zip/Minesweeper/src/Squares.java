public enum Squares {
    BLANK,
    FLAG,
    MINE,
    HITMINE,
    EXPOSED
}
